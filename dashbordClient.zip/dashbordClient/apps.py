from django.apps import AppConfig


class DashbordclientConfig(AppConfig):
    name = 'dashbordClient'
